## Summary
<!-- Short description -->

## Checklist
- [ ] Tests cover the change (incl. negative cases)
- [ ] Schemas validated (`schema-ci` green)
- [ ] Docs/fixtures updated if schema changed

## Notes
<!-- Anything reviewers should pay attention to -->
