# ZKPIP Roadmap — MVS v1.0 (excerpt)

> **Executive Summary:** ZKPIP MVS v1.0 delivers a stable foundation for ZK proof-bundle validation with four baseline adapters, a CLI toolchain, and the first Light Seal (single and batch) — providing an OSS-ready and grant-ready product for Ethereum developers.

**Deliverables (current focus):**
- [IDE MINDIG AZ AKTUÁLIS DELIVERABLES LISTÁT MÁSOLJUK BE]

**Timeline:** ~18 weeks total (MVS v1.0 release target)

---

👉 This thread relates to the ZKPIP MVS v1.0 roadmap above.
